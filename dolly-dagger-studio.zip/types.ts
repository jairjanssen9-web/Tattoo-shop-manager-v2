import React from 'react';

export enum UserRole {
  OWNER = 'OWNER',
  ARTIST = 'ARTIST',
  RECEPTION = 'RECEPTION'
}

export enum AppointmentStatus {
  REQUESTED = 'REQUESTED',
  CONFIRMED = 'CONFIRMED',
  IN_PROGRESS = 'IN_PROGRESS',
  DONE = 'DONE',
  CANCELLED = 'CANCELLED'
}

export interface User {
  id: string;
  name: string;
  role: UserRole;
  avatar: string;
}

export interface Client {
  id: string;
  name: string;
  email: string;
  phone: string;
  instagram?: string; 
  medicalNotes: string; 
  tags: string[]; 
  waiverSigned: boolean;
  waiverDate?: string;
}

export interface Appointment {
  id: string;
  clientId: string;
  artistId: string;
  date: string; 
  durationHours: number; // Inclusief 10 min setup
  description: string; 
  status: AppointmentStatus;
  price: number;
  depositPaid: boolean;
  images: string[]; 
  notes: Note[];
}

export interface Note {
  id: string;
  content: string;
  timestamp: string;
  authorId: string;
}

export interface QuickNote {
  id: string;
  content: string;
  timestamp: string;
}

export type InventoryType = 'CONSUMABLE' | 'UPSELL';
export type TransactionType = 'USAGE' | 'RESTOCK' | 'ADJUSTMENT';

export interface InventoryItem {
  id: string;
  name: string;
  category: string;
  type: InventoryType; 
  quantity: number;
  minQuantity: number;
  reorderLink: string;
}

export interface InventoryTransaction {
  id: string;
  itemId: string;
  itemName: string;
  change: number; // Negatief voor gebruik, positief voor restock
  type: TransactionType;
  timestamp: string;
}

export type ExpenseType = 'FIXED' | 'VARIABLE';

export interface Expense {
  id: string;
  name: string;
  type: ExpenseType;
  estimatedAmount: number; 
  actualAmount: number;    
  date: string;
  category: string; 
}

export interface Receipt {
  id: string;
  imageUrl: string;
  date: string;
  amount?: number;
  description?: string;
}

// Global State Context Type
export interface AppState {
  currentUser: User;
  users: User[];
  clients: Client[];
  appointments: Appointment[];
  inventory: InventoryItem[];
  inventoryTransactions: InventoryTransaction[]; // Nieuw
  quickNotes: QuickNote[];
  expenses: Expense[]; 
  receipts: Receipt[]; 
}

export interface AppContextType {
  state: AppState;
  dispatch: React.Dispatch<any>;
}