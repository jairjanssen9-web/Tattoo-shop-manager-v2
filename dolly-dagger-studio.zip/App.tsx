import React, { useState, useContext, createContext, useMemo, useEffect, useRef } from 'react';
import { 
  LayoutDashboard, 
  Calendar, 
  Users, 
  Package, 
  DollarSign, 
  Plus, 
  Search, 
  Menu, 
  X,
  CheckCircle,
  AlertCircle,
  Clock,
  FileText,
  ExternalLink,
  ChevronRight,
  ChevronLeft,
  Trash2,
  Send,
  Instagram,
  Edit2,
  Save,
  TrendingDown,
  TrendingUp,
  PieChart,
  LogIn,
  LogOut,
  Mail,
  ShoppingBag,
  Syringe,
  Receipt,
  Camera,
  Upload,
  History,
  Filter
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  LineChart,
  Line,
  Legend,
  AreaChart,
  Area
} from 'recharts';
import { 
  User, 
  UserRole, 
  AppointmentStatus, 
  AppState, 
  Appointment, 
  InventoryItem, 
  Client,
  QuickNote,
  Expense,
  ExpenseType,
  InventoryType,
  InventoryTransaction,
  Receipt as ReceiptType,
  TransactionType
} from './types';
import { mockUsers, mockClients, mockAppointments, mockInventory, mockExpenses, mockInventoryTransactions, mockReceipts } from './mockData';

// --- Context & State ---

const initialState: AppState = {
  currentUser: mockUsers[0],
  users: mockUsers,
  clients: mockClients,
  appointments: mockAppointments,
  inventory: mockInventory,
  inventoryTransactions: mockInventoryTransactions,
  quickNotes: [
    { id: 'qn1', content: 'Bestel nieuwe inktcups, bijna op!', timestamp: new Date().toISOString() }
  ],
  expenses: mockExpenses,
  receipts: mockReceipts
};

const AppContext = createContext<{
  state: AppState;
  updateState: (updates: Partial<AppState>) => void;
  navigate: (view: string) => void;
  currentView: string;
}>({
  state: initialState,
  updateState: () => {},
  navigate: () => {},
  currentView: 'dashboard'
});

// --- Helper Functions ---

const formatDateForInput = (isoString: string) => {
  if (!isoString) return '';
  const date = new Date(isoString);
  // Create a date object that represents the local time as if it were UTC
  // This is a common trick to make datetime-local inputs work with ISO strings while preserving local time values
  const localDate = new Date(date.getTime() - (date.getTimezoneOffset() * 60000));
  return localDate.toISOString().slice(0, 16);
};

const translateStatus = (status: AppointmentStatus) => {
    switch (status) {
        case AppointmentStatus.REQUESTED: return 'Aangevraagd';
        case AppointmentStatus.CONFIRMED: return 'Bevestigd';
        case AppointmentStatus.IN_PROGRESS: return 'Bezig';
        case AppointmentStatus.DONE: return 'Afgerond';
        case AppointmentStatus.CANCELLED: return 'Geannuleerd';
        default: return status;
    }
};

// --- Components ---

const Card: React.FC<{ children: React.ReactNode; className?: string; title?: string; onClick?: React.MouseEventHandler<HTMLDivElement> }> = ({ children, className = '', title, onClick }) => (
  <div onClick={onClick} className={`bg-zinc-900 border border-zinc-800 rounded-xl p-6 shadow-sm ${className}`}>
    {title && <h3 className="text-lg font-semibold text-zinc-100 mb-4">{title}</h3>}
    {children}
  </div>
);

const Badge: React.FC<{ children: React.ReactNode; color?: 'red' | 'green' | 'blue' | 'yellow' | 'gray' }> = ({ children, color = 'gray' }) => {
  const colors = {
    red: 'bg-rose-500/10 text-rose-500 border-rose-500/20',
    green: 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20',
    blue: 'bg-blue-500/10 text-blue-500 border-blue-500/20',
    yellow: 'bg-amber-500/10 text-amber-500 border-amber-500/20',
    gray: 'bg-zinc-700/30 text-zinc-400 border-zinc-700',
  };
  return (
    <span className={`px-2.5 py-0.5 rounded-full text-xs font-medium border ${colors[color]}`}>
      {children}
    </span>
  );
};

const Button: React.FC<React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: 'primary' | 'secondary' | 'danger' | 'ghost' | 'success' }> = ({ 
  children, 
  variant = 'primary', 
  className = '', 
  ...props 
}) => {
  const baseStyle = "inline-flex items-center justify-center rounded-lg font-medium transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-zinc-900 disabled:opacity-50 disabled:cursor-not-allowed";
  const variants = {
    primary: "bg-rose-600 hover:bg-rose-700 text-white focus:ring-rose-500",
    secondary: "bg-zinc-800 hover:bg-zinc-700 text-zinc-100 focus:ring-zinc-600 border border-zinc-700",
    danger: "bg-red-900/50 hover:bg-red-900/70 text-red-200 border border-red-900",
    success: "bg-emerald-600 hover:bg-emerald-700 text-white focus:ring-emerald-500",
    ghost: "hover:bg-zinc-800/50 text-zinc-400 hover:text-zinc-100",
  };
  const size = "px-4 py-2 text-sm"; 

  return (
    <button className={`${baseStyle} ${variants[variant]} ${size} ${className}`} {...props}>
      {children}
    </button>
  );
};

const AppointmentModal = ({ 
    appointment, 
    preselectedDate, 
    onClose, 
    onSave 
}: { 
    appointment: Appointment | null, 
    preselectedDate?: string,
    onClose: () => void, 
    onSave: (a: Appointment) => void 
}) => {
    const { state } = useContext(AppContext);
    // Initialize form with existing appointment OR default values for new
    const initialForm: Partial<Appointment> = appointment || {
        clientId: state.clients[0]?.id || '',
        artistId: state.users.find(u => u.role === UserRole.ARTIST)?.id || '',
        date: preselectedDate || new Date().toISOString(),
        durationHours: 2,
        description: '',
        status: AppointmentStatus.CONFIRMED,
        price: 150,
        depositPaid: false,
    };
    
    const [formData, setFormData] = useState(initialForm);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        
        const duration = parseFloat(formData.durationHours?.toString() || '0');
        const finalDuration = duration; 

        const finalAppointment: Appointment = {
            id: appointment?.id || `a${Date.now()}`,
            clientId: formData.clientId!,
            artistId: formData.artistId!,
            date: formData.date!,
            durationHours: finalDuration,
            description: formData.description || '',
            status: formData.status || AppointmentStatus.REQUESTED,
            price: Number(formData.price),
            depositPaid: formData.depositPaid || false,
            images: appointment?.images || [],
            notes: appointment?.notes || []
        };
        onSave(finalAppointment);
    };

    return (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="bg-zinc-900 border border-zinc-800 w-full max-w-lg rounded-xl p-6 relative max-h-[90vh] overflow-y-auto">
                <button onClick={onClose} className="absolute top-4 right-4 text-zinc-400 hover:text-white"><X size={20}/></button>
                <h3 className="text-xl font-bold text-white mb-6">{appointment ? 'Afspraak Bewerken' : 'Nieuwe Afspraak'}</h3>
                
                <form onSubmit={handleSubmit} className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-1">
                            <label className="text-xs text-zinc-500">Klant</label>
                            <select className="w-full bg-zinc-800 border border-zinc-700 rounded px-3 py-2 text-white outline-none"
                                value={formData.clientId} onChange={e => setFormData({...formData, clientId: e.target.value})}>
                                {state.clients.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                            </select>
                        </div>
                        <div className="space-y-1">
                            <label className="text-xs text-zinc-500">Artiest</label>
                            <select className="w-full bg-zinc-800 border border-zinc-700 rounded px-3 py-2 text-white outline-none"
                                value={formData.artistId} onChange={e => setFormData({...formData, artistId: e.target.value})}>
                                {state.users.filter(u => u.role === UserRole.ARTIST).map(u => <option key={u.id} value={u.id}>{u.name}</option>)}
                            </select>
                        </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-1">
                            <label className="text-xs text-zinc-500">Datum & Tijd</label>
                            <input 
                                type="datetime-local" 
                                className="w-full bg-zinc-800 border border-zinc-700 rounded px-3 py-2 text-white outline-none"
                                // Use the helper to display local time correctly
                                value={formatDateForInput(formData.date || '')}
                                onChange={e => {
                                    if (e.target.value) {
                                        setFormData({...formData, date: new Date(e.target.value).toISOString()})
                                    }
                                }} 
                            />
                        </div>
                        <div className="space-y-1">
                            <label className="text-xs text-zinc-500">Duur (Uur)</label>
                            <div className="flex items-center gap-2">
                                <input type="number" step="0.5" className="w-full bg-zinc-800 border border-zinc-700 rounded px-3 py-2 text-white outline-none"
                                    value={formData.durationHours} 
                                    onChange={e => setFormData({...formData, durationHours: parseFloat(e.target.value)})} />
                                <span className="text-xs text-zinc-500 whitespace-nowrap">+10min setup</span>
                            </div>
                        </div>
                    </div>

                    <div className="space-y-1">
                        <label className="text-xs text-zinc-500">Beschrijving</label>
                        <textarea className="w-full bg-zinc-800 border border-zinc-700 rounded px-3 py-2 text-white outline-none h-24 resize-none"
                            value={formData.description} onChange={e => setFormData({...formData, description: e.target.value})} />
                    </div>

                    <div className="grid grid-cols-3 gap-4">
                        <div className="space-y-1">
                            <label className="text-xs text-zinc-500">Prijs (€)</label>
                            <input type="number" className="w-full bg-zinc-800 border border-zinc-700 rounded px-3 py-2 text-white outline-none"
                                value={formData.price} onChange={e => setFormData({...formData, price: parseFloat(e.target.value)})} />
                        </div>
                        <div className="space-y-1">
                            <label className="text-xs text-zinc-500">Status</label>
                            <select className="w-full bg-zinc-800 border border-zinc-700 rounded px-3 py-2 text-white outline-none"
                                value={formData.status} onChange={e => setFormData({...formData, status: e.target.value as AppointmentStatus})}>
                                {Object.values(AppointmentStatus).map(s => <option key={s} value={s}>{translateStatus(s)}</option>)}
                            </select>
                        </div>
                         <div className="flex items-end pb-2">
                             <label className="flex items-center gap-2 cursor-pointer text-sm text-zinc-300">
                                <input type="checkbox" className="w-4 h-4 rounded bg-zinc-700 border-zinc-600 text-rose-600"
                                    checked={formData.depositPaid} onChange={e => setFormData({...formData, depositPaid: e.target.checked})} />
                                Aanbetaling
                             </label>
                         </div>
                    </div>

                    <div className="pt-4 flex justify-end gap-3 border-t border-zinc-800">
                         {appointment && (
                             <Button variant="danger" type="button" onClick={() => {
                                 const confirm = window.confirm("Weet je zeker dat je deze afspraak wilt verwijderen?");
                                 if(confirm) {
                                     onClose();
                                 }
                             }}>Verwijder</Button>
                         )}
                         <Button variant="secondary" type="button" onClick={onClose}>Annuleren</Button>
                         <Button type="submit">Opslaan</Button>
                    </div>
                </form>
            </div>
        </div>
    );
};

const ExpenseModal = ({ expense, onClose, onSave }: { expense: Expense, onClose: () => void, onSave: (e: Expense) => void }) => {
    const [formData, setFormData] = useState<Expense>(expense);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSave(formData);
    };

    return (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="bg-zinc-900 border border-zinc-800 w-full max-w-md rounded-xl p-6 relative">
                <button onClick={onClose} className="absolute top-4 right-4 text-zinc-400 hover:text-white"><X size={20}/></button>
                <h3 className="text-xl font-bold text-white mb-4">Kostenpost Bewerken</h3>
                
                <form onSubmit={handleSubmit} className="space-y-4">
                    <div className="space-y-1">
                        <label className="text-xs text-zinc-500">Omschrijving</label>
                        <input className="w-full bg-zinc-800 border border-zinc-700 rounded px-3 py-2 text-white outline-none"
                            value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-1">
                             <label className="text-xs text-zinc-500">Bedrag (€)</label>
                             <input type="number" className="w-full bg-zinc-800 border border-zinc-700 rounded px-3 py-2 text-white outline-none"
                                value={formData.actualAmount} onChange={e => setFormData({...formData, actualAmount: parseFloat(e.target.value)})} />
                        </div>
                        <div className="space-y-1">
                             <label className="text-xs text-zinc-500">Categorie</label>
                             <input className="w-full bg-zinc-800 border border-zinc-700 rounded px-3 py-2 text-white outline-none"
                                value={formData.category} onChange={e => setFormData({...formData, category: e.target.value})} />
                        </div>
                    </div>
                    <div className="space-y-1">
                        <label className="text-xs text-zinc-500">Type</label>
                        <select className="w-full bg-zinc-800 border border-zinc-700 rounded px-3 py-2 text-white outline-none"
                            value={formData.type} onChange={e => setFormData({...formData, type: e.target.value as ExpenseType})}>
                            <option value="VARIABLE">Variabel / Eenmalig</option>
                            <option value="FIXED">Vast / Maandelijks</option>
                        </select>
                    </div>

                    <div className="pt-4 flex justify-end gap-3 border-t border-zinc-800">
                         <Button variant="secondary" type="button" onClick={onClose}>Annuleren</Button>
                         <Button type="submit">Opslaan</Button>
                    </div>
                </form>
            </div>
        </div>
    );
};

// --- Views ---

const DashboardView = () => {
  const { state, updateState, navigate } = useContext(AppContext);
  const [newNote, setNewNote] = useState('');
  const [selectedAppointment, setSelectedAppointment] = useState<Appointment | null>(null);
  const [isEditingApt, setIsEditingApt] = useState(false);
  
  const today = new Date().toISOString().split('T')[0];
  const todayAppointments = state.appointments.filter(a => a.date.startsWith(today)).sort((a, b) => a.date.localeCompare(b.date));
  const lowStock = state.inventory.filter(i => i.quantity <= i.minQuantity);
  
  const dailyRevenue = state.appointments
    .filter(a => a.status === AppointmentStatus.DONE || a.status === AppointmentStatus.CONFIRMED)
    .reduce((sum, a) => sum + (a.status === AppointmentStatus.DONE ? a.price : 0), 0);

  const handleAddNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newNote.trim()) return;
    const note: QuickNote = {
        id: `qn${Date.now()}`,
        content: newNote,
        timestamp: new Date().toISOString()
    };
    updateState({ quickNotes: [note, ...state.quickNotes] });
    setNewNote('');
  };

  const deleteNote = (id: string) => {
      updateState({ quickNotes: state.quickNotes.filter(n => n.id !== id) });
  };

  const handleCheckIn = (apt: Appointment) => {
      const updatedApts = state.appointments.map(a => a.id === apt.id ? { ...a, status: AppointmentStatus.IN_PROGRESS } : a);
      
      const newTransactions: InventoryTransaction[] = [];
      const updatedInventory = state.inventory.map(item => {
          if (item.type === 'CONSUMABLE' && ['Naalden', 'Hygiëne'].includes(item.category)) {
              const qty = Math.max(0, item.quantity - 1);
              if (item.quantity > 0) {
                 newTransactions.push({
                    id: `tx${Date.now()}-${item.id}`,
                    itemId: item.id,
                    itemName: item.name,
                    change: -1,
                    type: 'USAGE',
                    timestamp: new Date().toISOString()
                 });
              }
              return { ...item, quantity: qty };
          }
          return item;
      });

      updateState({ 
          appointments: updatedApts, 
          inventory: updatedInventory,
          inventoryTransactions: [...state.inventoryTransactions, ...newTransactions]
      });
      setSelectedAppointment(null);
  };

  const handleCheckOut = (apt: Appointment) => {
      const updatedApts = state.appointments.map(a => a.id === apt.id ? { ...a, status: AppointmentStatus.DONE } : a);
      updateState({ appointments: updatedApts });
      setSelectedAppointment(null);
  };

  const handleSaveApt = (updated: Appointment) => {
       const updatedList = state.appointments.map(a => a.id === updated.id ? updated : a);
       updateState({ appointments: updatedList });
       setIsEditingApt(false);
       setSelectedAppointment(null);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      {isEditingApt && selectedAppointment && (
          <AppointmentModal 
            appointment={selectedAppointment} 
            onClose={() => { setIsEditingApt(false); }} 
            onSave={handleSaveApt} 
          />
      )}

      {selectedAppointment && !isEditingApt && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="bg-zinc-900 border border-zinc-800 w-full max-w-md rounded-xl p-6 relative">
                <button onClick={() => setSelectedAppointment(null)} className="absolute top-4 right-4 text-zinc-400 hover:text-white">
                    <X size={20} />
                </button>
                <h3 className="text-xl font-bold text-white mb-1">Afspraak Details</h3>
                <p className="text-rose-500 font-mono mb-4">{new Date(selectedAppointment.date).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})} - {translateStatus(selectedAppointment.status)}</p>
                
                <div className="space-y-4 text-sm text-zinc-300">
                    <div className="bg-zinc-800/50 p-3 rounded-lg">
                        <p className="text-zinc-500 text-xs uppercase mb-1">Klant</p>
                        <p className="font-semibold text-white">{state.clients.find(c => c.id === selectedAppointment.clientId)?.name}</p>
                    </div>
                    <div className="bg-zinc-800/50 p-3 rounded-lg">
                        <p className="text-zinc-500 text-xs uppercase mb-1">Ontwerp</p>
                        <p>{selectedAppointment.description}</p>
                    </div>

                    <div className="grid grid-cols-2 gap-3 pt-2">
                        {selectedAppointment.status === AppointmentStatus.CONFIRMED && (
                             <Button onClick={() => handleCheckIn(selectedAppointment)} variant="success" className="col-span-2 flex items-center gap-2">
                                <LogIn size={16} /> Check-in (Start & Afboeken)
                             </Button>
                        )}
                        {selectedAppointment.status === AppointmentStatus.IN_PROGRESS && (
                             <Button onClick={() => handleCheckOut(selectedAppointment)} variant="primary" className="col-span-2 flex items-center gap-2">
                                <LogOut size={16} /> Check-out (Afronden & Betalen)
                             </Button>
                        )}
                        
                        <Button variant="secondary" onClick={() => setIsEditingApt(true)} className="flex items-center gap-2">
                            <Edit2 size={16} /> Bewerken
                        </Button>
                        <Button variant="secondary" onClick={() => { setSelectedAppointment(null); navigate('agenda'); }}>
                            Naar Agenda
                        </Button>
                    </div>
                </div>
            </div>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-br from-rose-900/40 to-zinc-900 border-rose-900/50">
          <p className="text-sm text-rose-200/70 font-medium">Omzet Vandaag</p>
          <p className="text-3xl font-bold text-white mt-2">€{dailyRevenue}</p>
        </Card>
        <Card>
          <p className="text-sm text-zinc-400 font-medium">Afspraken Vandaag</p>
          <p className="text-3xl font-bold text-zinc-100 mt-2">{todayAppointments.length}</p>
        </Card>
        <Card>
          <p className="text-sm text-zinc-400 font-medium">Voorraad Waarschuwingen</p>
          <p className={`text-3xl font-bold mt-2 ${lowStock.length > 0 ? 'text-amber-500' : 'text-zinc-100'}`}>
            {lowStock.length}
          </p>
        </Card>
        <Card>
          <p className="text-sm text-zinc-400 font-medium">Openstaande Aanvragen</p>
          <p className="text-3xl font-bold text-zinc-100 mt-2">
            {state.appointments.filter(a => a.status === AppointmentStatus.REQUESTED).length}
          </p>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <Card title="Vandaag op de planning">
            {todayAppointments.length === 0 ? (
              <p className="text-zinc-500 italic">Geen afspraken voor vandaag.</p>
            ) : (
              <div className="space-y-4">
                {todayAppointments.map(apt => {
                  const client = state.clients.find(c => c.id === apt.clientId);
                  const artist = state.users.find(u => u.id === apt.artistId);
                  return (
                    <div 
                        key={apt.id} 
                        onClick={() => setSelectedAppointment(apt)}
                        className="flex items-center justify-between p-4 bg-zinc-800/50 rounded-lg border border-zinc-700/50 hover:bg-zinc-800 hover:border-rose-500/30 cursor-pointer transition-all"
                    >
                      <div className="flex items-start gap-4">
                        <div className="w-12 h-12 rounded-full bg-zinc-700 flex items-center justify-center flex-shrink-0 text-zinc-400 font-bold">
                           {new Date(apt.date).getHours()}:00
                        </div>
                        <div>
                          <p className="font-semibold text-zinc-100">{client?.name}</p>
                          <p className="text-sm text-zinc-400">{apt.description} • {apt.durationHours.toFixed(1)}u</p>
                          <div className="flex gap-2 mt-2">
                            <Badge color="blue">{artist?.name}</Badge>
                            <Badge color={apt.status === AppointmentStatus.DONE ? 'green' : apt.status === AppointmentStatus.IN_PROGRESS ? 'red' : 'yellow'}>
                                {translateStatus(apt.status)}
                            </Badge>
                          </div>
                        </div>
                      </div>
                      <ChevronRight className="text-zinc-600" />
                    </div>
                  );
                })}
              </div>
            )}
          </Card>
        </div>

        <div className="space-y-6">
          <Card title="Snelle Notities & Taken">
             <form onSubmit={handleAddNote} className="flex gap-2 mb-4">
                 <input 
                    type="text" 
                    value={newNote}
                    onChange={(e) => setNewNote(e.target.value)}
                    placeholder="Typ een notitie..."
                    className="flex-1 bg-zinc-800 border border-zinc-700 rounded-lg px-3 py-2 text-sm text-white focus:ring-2 focus:ring-rose-500 outline-none"
                 />
                 <Button type="submit" className="px-3"><Send size={16}/></Button>
             </form>
             
             <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
                 {state.quickNotes.length === 0 && <p className="text-zinc-600 text-xs italic">Geen notities.</p>}
                 {state.quickNotes.map(note => (
                     <div key={note.id} className="group flex justify-between items-start bg-zinc-800/30 p-2 rounded text-sm hover:bg-zinc-800 transition-colors">
                         <div>
                             <p className="text-zinc-300">{note.content}</p>
                             <p className="text-xs text-zinc-600 mt-1">{new Date(note.timestamp).toLocaleDateString()} {new Date(note.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</p>
                         </div>
                         <button onClick={() => deleteNote(note.id)} className="text-zinc-600 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity">
                             <Trash2 size={14} />
                         </button>
                     </div>
                 ))}
             </div>
          </Card>

          {lowStock.length > 0 && (
            <Card title="Voorraad Alerts">
              <div className="space-y-3">
                {lowStock.map(item => (
                  <div key={item.id} className="flex items-center justify-between p-3 bg-amber-900/10 border border-amber-900/30 rounded-lg">
                    <div>
                      <p className="font-medium text-amber-200">{item.name}</p>
                      <p className="text-xs text-amber-200/60">{item.quantity} over (Min: {item.minQuantity})</p>
                    </div>
                    <a href={item.reorderLink} target="_blank" rel="noreferrer" className="p-2 bg-amber-900/20 text-amber-200 rounded-lg hover:bg-amber-900/40">
                      <ExternalLink size={16} />
                    </a>
                  </div>
                ))}
              </div>
            </Card>
          )}
          
          <Card title="Snelmenu">
            <button className="w-full text-left p-3 hover:bg-zinc-800 rounded-lg transition-colors text-sm text-zinc-300 flex items-center gap-2">
              <FileText size={16} /> Consent Formulieren
            </button>
          </Card>
        </div>
      </div>
    </div>
  );
};

const AgendaView = () => {
    const { state, updateState } = useContext(AppContext);
    const [viewMode, setViewMode] = useState<'day' | 'week' | 'month'>('month');
    const [currentDate, setCurrentDate] = useState(new Date());
    const [modalOpen, setModalOpen] = useState(false);
    const [editingApt, setEditingApt] = useState<Appointment | null>(null);
    const [newDatePreselect, setNewDatePreselect] = useState<string | undefined>(undefined);

    const getStartOfWeek = (d: Date) => { const date = new Date(d); const day = date.getDay(); const diff = date.getDate() - day + (day === 0 ? -6 : 1); return new Date(date.setDate(diff)); };
    const addDays = (d: Date, days: number) => { const date = new Date(d); date.setDate(date.getDate() + days); return date; };
    const addMonths = (d: Date, months: number) => { const date = new Date(d); date.setMonth(date.getMonth() + months); return date; };

    const handlePrev = () => { if (viewMode === 'day') setCurrentDate(addDays(currentDate, -1)); if (viewMode === 'week') setCurrentDate(addDays(currentDate, -7)); if (viewMode === 'month') setCurrentDate(addMonths(currentDate, -1)); };
    const handleNext = () => { if (viewMode === 'day') setCurrentDate(addDays(currentDate, 1)); if (viewMode === 'week') setCurrentDate(addDays(currentDate, 7)); if (viewMode === 'month') setCurrentDate(addMonths(currentDate, 1)); };

    const handleNewAppointment = (dateStr: string) => { const date = new Date(dateStr); date.setHours(12,0,0,0); setNewDatePreselect(date.toISOString()); setEditingApt(null); setModalOpen(true); };
    const handleEditAppointment = (apt: Appointment, e: React.MouseEvent) => { e.stopPropagation(); setEditingApt(apt); setModalOpen(true); };
    const handleSaveAppointment = (apt: Appointment) => { 
        const isNew = !state.appointments.find(a => a.id === apt.id); 
        let updatedList = isNew ? [...state.appointments, apt] : state.appointments.map(a => a.id === apt.id ? apt : a); 
        updateState({ appointments: updatedList }); 
        setModalOpen(false); 
    };

    const renderMonthView = () => {
        const year = currentDate.getFullYear();
        const month = currentDate.getMonth();
        const firstDayOfMonth = new Date(year, month, 1);
        const daysInMonth = new Date(year, month + 1, 0).getDate();
        const startDay = (firstDayOfMonth.getDay() + 6) % 7; 
        
        const emptyDays = Array.from({ length: startDay }, (_, i) => i);
        const days = Array.from({ length: daysInMonth }, (_, i) => i + 1);

        return (
            <div className="border border-zinc-800 rounded-lg overflow-hidden bg-zinc-900">
                <div className="grid grid-cols-7 border-b border-zinc-800 bg-zinc-950">
                    {['Ma', 'Di', 'Wo', 'Do', 'Vr', 'Za', 'Zo'].map(day => (
                        <div key={day} className="p-3 text-center text-sm font-bold text-zinc-500 uppercase">{day}</div>
                    ))}
                </div>
                <div className="grid grid-cols-7 auto-rows-[120px]">
                    {emptyDays.map(i => <div key={`empty-${i}`} className="border-r border-b border-zinc-800 bg-zinc-950/30"></div>)}
                    {days.map(d => {
                        const dateStr = new Date(year, month, d).toISOString().split('T')[0];
                        const dayApts = state.appointments.filter(a => a.date.startsWith(dateStr));
                        const isToday = new Date().toDateString() === new Date(year, month, d).toDateString();

                        return (
                            <div 
                                key={d} 
                                onClick={() => handleNewAppointment(dateStr)}
                                className={`p-2 border-r border-b border-zinc-800 relative hover:bg-zinc-800/50 cursor-pointer transition-colors group ${isToday ? 'bg-rose-900/10' : ''}`}
                            >
                                <span className={`text-sm font-bold ${isToday ? 'text-rose-500' : 'text-zinc-400'}`}>{d}</span>
                                <div className="mt-1 flex flex-col gap-1 overflow-hidden h-[80px]">
                                    {dayApts.map(a => (
                                        <div 
                                            key={a.id} 
                                            onClick={(e) => handleEditAppointment(a, e)}
                                            className="bg-rose-600/20 border-l-2 border-rose-500 pl-1 text-[10px] text-zinc-200 truncate hover:bg-rose-600 hover:text-white transition-colors"
                                            title={state.clients.find(c => c.id === a.clientId)?.name}
                                        >
                                            {new Date(a.date).toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'})} {state.clients.find(c => c.id === a.clientId)?.name}
                                        </div>
                                    ))}
                                </div>
                                <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
                                    <Plus size={14} className="text-zinc-500" />
                                </div>
                            </div>
                        );
                    })}
                </div>
            </div>
        );
    };

    const renderDayWeekView = () => {
        const startDate = viewMode === 'week' ? getStartOfWeek(currentDate) : currentDate;
        const days = viewMode === 'week' ? 7 : 1;
        const daysArr = Array.from({ length: days }, (_, i) => addDays(startDate, i));

        return (
            <div className={`grid gap-4 ${viewMode === 'week' ? 'grid-cols-1 md:grid-cols-7' : 'grid-cols-1'}`}>
                {daysArr.map(day => (
                    <div key={day.toISOString()} className="bg-zinc-900 border border-zinc-800 rounded-xl min-h-[300px] p-2">
                        <div className="text-center border-b border-zinc-800 pb-2 mb-2">
                            <p className="text-zinc-400 text-xs uppercase">{day.toLocaleDateString('nl-NL', { weekday: 'short' })}</p>
                            <p className={`text-lg font-bold ${day.toDateString() === new Date().toDateString() ? 'text-rose-500' : 'text-zinc-200'}`}>
                                {day.getDate()}
                            </p>
                        </div>
                        <div className="space-y-2">
                            {state.appointments
                                .filter(a => new Date(a.date).toDateString() === day.toDateString())
                                .sort((a,b) => new Date(a.date).getTime() - new Date(b.date).getTime())
                                .map(apt => (
                                    <div 
                                        key={apt.id} 
                                        onClick={(e) => handleEditAppointment(apt, e)}
                                        className="bg-zinc-800/80 p-2 rounded border border-zinc-700 hover:border-rose-500 cursor-pointer text-xs"
                                    >
                                        <div className="flex justify-between mb-1">
                                            <span className="font-bold text-zinc-300">{new Date(apt.date).toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'})}</span>
                                        </div>
                                        <p className="text-white truncate">{state.clients.find(c => c.id === apt.clientId)?.name}</p>
                                        <div className="mt-1 flex justify-between items-center">
                                            <span className="text-zinc-500 truncate max-w-[80px]">{state.users.find(u => u.id === apt.artistId)?.name}</span>
                                            <Badge color={apt.status === AppointmentStatus.DONE ? 'green' : 'gray'}>
                                                {apt.status === AppointmentStatus.DONE ? '✓' : '•'}
                                            </Badge>
                                        </div>
                                    </div>
                                ))
                            }
                            <button 
                                onClick={() => handleNewAppointment(day.toISOString())} 
                                className="w-full py-2 text-zinc-600 hover:text-zinc-400 text-xs border border-dashed border-zinc-800 hover:border-zinc-600 rounded"
                            >
                                +
                            </button>
                        </div>
                    </div>
                ))}
            </div>
        );
    };

    return (
        <div className="space-y-6 animate-in fade-in duration-500">
            {modalOpen && (
                <AppointmentModal 
                    appointment={editingApt} 
                    preselectedDate={newDatePreselect}
                    onClose={() => setModalOpen(false)} 
                    onSave={handleSaveAppointment} 
                />
            )}

            <div className="flex justify-between items-center bg-zinc-900 p-4 rounded-xl border border-zinc-800">
                <div className="flex items-center gap-4">
                    <div className="flex bg-zinc-800 rounded-lg p-1">
                        <button onClick={() => setViewMode('day')} className={`px-3 py-1 text-sm rounded ${viewMode === 'day' ? 'bg-zinc-600 text-white' : 'text-zinc-400'}`}>Dag</button>
                        <button onClick={() => setViewMode('week')} className={`px-3 py-1 text-sm rounded ${viewMode === 'week' ? 'bg-zinc-600 text-white' : 'text-zinc-400'}`}>Week</button>
                        <button onClick={() => setViewMode('month')} className={`px-3 py-1 text-sm rounded ${viewMode === 'month' ? 'bg-zinc-600 text-white' : 'text-zinc-400'}`}>Maand</button>
                    </div>
                    <h2 className="text-xl font-bold text-white capitalize">
                        {currentDate.toLocaleDateString('nl-NL', { month: 'long', year: 'numeric' })}
                    </h2>
                </div>
                <div className="flex gap-2">
                    <button onClick={handlePrev} className="p-2 hover:bg-zinc-800 rounded text-zinc-300"><ChevronLeft/></button>
                    <button onClick={() => setCurrentDate(new Date())} className="px-3 py-2 hover:bg-zinc-800 rounded text-sm text-zinc-300">Vandaag</button>
                    <button onClick={handleNext} className="p-2 hover:bg-zinc-800 rounded text-zinc-300"><ChevronRight/></button>
                </div>
            </div>

            {viewMode === 'month' ? renderMonthView() : renderDayWeekView()}
        </div>
    );
};

const ClientModal = ({ client, onClose, onSave }: { client: Client, onClose: () => void, onSave: (c: Client) => void }) => {
    const [formData, setFormData] = useState<Client>(client);
    const isNew = !client.id; // Assume empty ID means new

    const handleSubmit = () => {
        // Generate ID if new
        const finalClient = isNew ? { ...formData, id: `c${Date.now()}` } : formData;
        onSave(finalClient);
    };

    return (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="bg-zinc-900 border border-zinc-800 w-full max-w-2xl rounded-xl p-6 relative max-h-[90vh] overflow-y-auto">
                <div className="flex justify-between items-center mb-6">
                    <h3 className="text-xl font-bold text-white flex items-center gap-2">
                        {isNew ? <Plus size={20} className="text-rose-500" /> : <Edit2 size={20} className="text-rose-500" />} 
                        {isNew ? 'Nieuwe Klant Toevoegen' : 'Bewerk Klantprofiel'}
                    </h3>
                    <button onClick={onClose} className="text-zinc-400 hover:text-white"><X size={24}/></button>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                        <div><label className="block text-xs font-medium text-zinc-500 mb-1">Volledige Naam</label><input className="w-full bg-zinc-800 border border-zinc-700 rounded px-3 py-2 text-white outline-none focus:ring-1 focus:ring-rose-500" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} /></div>
                        <div><label className="block text-xs font-medium text-zinc-500 mb-1">Email Adres</label><input className="w-full bg-zinc-800 border border-zinc-700 rounded px-3 py-2 text-white outline-none focus:ring-1 focus:ring-rose-500" value={formData.email} onChange={e => setFormData({...formData, email: e.target.value})} /></div>
                        <div><label className="block text-xs font-medium text-zinc-500 mb-1">Telefoonnummer</label><input className="w-full bg-zinc-800 border border-zinc-700 rounded px-3 py-2 text-white outline-none focus:ring-1 focus:ring-rose-500" value={formData.phone} onChange={e => setFormData({...formData, phone: e.target.value})} /></div>
                        <div><label className="block text-xs font-medium text-zinc-500 mb-1">Instagram</label><input className="w-full bg-zinc-800 border border-zinc-700 rounded px-3 py-2 text-white outline-none focus:ring-1 focus:ring-rose-500" value={formData.instagram || ''} onChange={e => setFormData({...formData, instagram: e.target.value})} /></div>
                    </div>
                    <div className="space-y-4">
                        <div><label className="block text-xs font-medium text-zinc-500 mb-1">Medische Notities</label><textarea className="w-full bg-zinc-800 border border-zinc-700 rounded px-3 py-2 text-white outline-none focus:ring-1 focus:ring-rose-500 h-32 resize-none" value={formData.medicalNotes} onChange={e => setFormData({...formData, medicalNotes: e.target.value})} /></div>
                        <div><label className="block text-xs font-medium text-zinc-500 mb-1">Tags</label><input className="w-full bg-zinc-800 border border-zinc-700 rounded px-3 py-2 text-white outline-none focus:ring-1 focus:ring-rose-500" value={formData.tags.join(', ')} onChange={e => setFormData({...formData, tags: e.target.value.split(',').map(t => t.trim())})} /></div>
                        <div className="flex items-center gap-3 pt-2"><label className="flex items-center gap-2 text-sm text-zinc-300 cursor-pointer"><input type="checkbox" className="w-4 h-4 rounded border-zinc-600 bg-zinc-700 text-rose-500" checked={formData.waiverSigned} onChange={e => setFormData({...formData, waiverSigned: e.target.checked})} />Waiver Getekend</label></div>
                    </div>
                </div>
                <div className="mt-8 flex justify-end gap-3 pt-4 border-t border-zinc-800">
                    <Button variant="secondary" onClick={onClose}>Annuleren</Button>
                    <Button onClick={handleSubmit} className="flex items-center gap-2"><Save size={16} /> {isNew ? 'Toevoegen' : 'Opslaan'}</Button>
                </div>
            </div>
        </div>
    );
};

const ClientsView = () => {
    const { state, updateState } = useContext(AppContext);
    const [filter, setFilter] = useState('');
    const [editingClient, setEditingClient] = useState<Client | null>(null);
    const [isCreating, setIsCreating] = useState(false);

    const filteredClients = state.clients.filter(c => c.name.toLowerCase().includes(filter.toLowerCase()) || c.email.includes(filter.toLowerCase()));
    
    const handleSaveClient = (client: Client) => { 
        if (isCreating) {
            updateState({ clients: [...state.clients, client] });
            setIsCreating(false);
        } else {
            const updatedList = state.clients.map(c => c.id === client.id ? client : c); 
            updateState({ clients: updatedList }); 
            setEditingClient(null); 
        }
    };

    const handleCreateClient = () => {
        setIsCreating(true);
    };

    const emptyClient: Client = {
        id: '',
        name: '',
        email: '',
        phone: '',
        medicalNotes: '',
        tags: [],
        waiverSigned: false
    };

    return (
        <div className="space-y-6 animate-in fade-in duration-500">
            {(editingClient || isCreating) && (
                <ClientModal 
                    client={editingClient || emptyClient} 
                    onClose={() => { setEditingClient(null); setIsCreating(false); }} 
                    onSave={handleSaveClient} 
                />
            )}
            <div className="flex justify-between items-center">
                <div className="flex items-center gap-4 bg-zinc-900 p-4 rounded-xl border border-zinc-800 flex-1 mr-4">
                    <Search className="text-zinc-500" />
                    <input className="bg-transparent outline-none w-full text-zinc-100 placeholder-zinc-500" placeholder="Zoek klanten..." value={filter} onChange={(e) => setFilter(e.target.value)}/>
                </div>
                <Button onClick={handleCreateClient} className="h-14 px-6 flex items-center gap-2 shadow-lg shadow-rose-900/20">
                    <Plus size={20} /> Nieuwe Klant
                </Button>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">{filteredClients.map(client => (<Card key={client.id} className="hover:border-zinc-500 transition-colors cursor-pointer group relative"><div onClick={() => setEditingClient(client)}><div className="flex justify-between items-start"><h3 className="font-bold text-lg text-white group-hover:text-rose-500 transition-colors">{client.name}</h3><div className="flex gap-2">{client.tags.includes('VIP') && <Badge color="yellow">VIP</Badge>}</div></div><p className="text-zinc-400 text-sm mt-1">{client.email}</p><p className="text-zinc-400 text-sm">{client.phone}</p>{client.instagram && (<a href={`https://instagram.com/${client.instagram.replace('@', '')}`} target="_blank" rel="noreferrer" onClick={(e) => e.stopPropagation()} className="inline-flex items-center gap-1 text-rose-400 text-xs mt-2 hover:underline"><Instagram size={12} /> @{client.instagram.replace('@', '')}</a>)}<div className="mt-4 pt-4 border-t border-zinc-800">{client.medicalNotes && client.medicalNotes !== 'Geen' && (<div className="flex items-start gap-2 text-xs text-rose-300 bg-rose-900/10 p-2 rounded mb-2"><AlertCircle size={12} className="mt-0.5" />{client.medicalNotes}</div>)}<div className="flex justify-between items-center text-xs text-zinc-500"><span>Historie: {state.appointments.filter(a => a.clientId === client.id).length} bezoeken</span>{client.waiverSigned ? (<span className="flex items-center gap-1 text-emerald-500"><CheckCircle size={12}/> Waiver OK</span>) : (<span className="flex items-center gap-1 text-amber-500"><AlertCircle size={12}/> Geen Waiver</span>)}</div></div></div><div className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity"><Edit2 size={16} className="text-zinc-500" /></div></Card>))}</div>
        </div>
    );
};

const InventoryView = () => {
  const { state, updateState } = useContext(AppContext);
  const [activeTab, setActiveTab] = useState<'current' | 'history'>('current');
  const [newItem, setNewItem] = useState({ name: '', category: '', type: 'CONSUMABLE', quantity: 0, minQuantity: 0 });
  const [showAddForm, setShowAddForm] = useState(false);

  const handleQuantityChange = (id: string, delta: number, name: string) => {
    const updated = state.inventory.map(item => 
        item.id === id ? { ...item, quantity: Math.max(0, item.quantity + delta) } : item
    );
    
    const transaction: InventoryTransaction = {
        id: `tx${Date.now()}`,
        itemId: id,
        itemName: name,
        change: delta,
        type: delta > 0 ? 'RESTOCK' : 'USAGE',
        timestamp: new Date().toISOString()
    };
    
    updateState({ 
        inventory: updated,
        inventoryTransactions: [transaction, ...state.inventoryTransactions]
    });
  };

  const handleAddItem = (e: React.FormEvent) => {
      e.preventDefault();
      const item: InventoryItem = {
          id: `i${Date.now()}`,
          name: newItem.name,
          category: newItem.category,
          type: newItem.type as InventoryType,
          quantity: Number(newItem.quantity),
          minQuantity: Number(newItem.minQuantity),
          reorderLink: '#'
      };
      // Log initial stock
      const transaction: InventoryTransaction = {
          id: `tx${Date.now()}`,
          itemId: item.id,
          itemName: item.name,
          change: item.quantity,
          type: 'RESTOCK',
          timestamp: new Date().toISOString()
      };

      updateState({ 
          inventory: [...state.inventory, item],
          inventoryTransactions: [transaction, ...state.inventoryTransactions]
      });
      setShowAddForm(false);
      setNewItem({ name: '', category: '', type: 'CONSUMABLE', quantity: 0, minQuantity: 0 });
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
        <div className="flex justify-between items-center">
             <h2 className="text-2xl font-bold text-white">Voorraad</h2>
             <div className="flex gap-4 items-center">
                 <div className="flex bg-zinc-800 rounded-lg p-1">
                     <button onClick={() => setActiveTab('current')} className={`px-4 py-2 text-sm rounded-md transition-all ${activeTab === 'current' ? 'bg-zinc-600 text-white shadow' : 'text-zinc-400 hover:text-white'}`}>Overzicht</button>
                     <button onClick={() => setActiveTab('history')} className={`px-4 py-2 text-sm rounded-md transition-all ${activeTab === 'history' ? 'bg-zinc-600 text-white shadow' : 'text-zinc-400 hover:text-white'}`}>Geschiedenis</button>
                 </div>
                 <Button variant="secondary" onClick={() => setShowAddForm(!showAddForm)}>
                    <Plus size={16}/> Item
                </Button>
            </div>
        </div>

        {showAddForm && (
                <Card title="Nieuw Item" className="animate-in slide-in-from-top-4 mb-4">
                    <form onSubmit={handleAddItem} className="space-y-4">
                        <div className="grid grid-cols-2 gap-4">
                            <input className="bg-zinc-800 border-zinc-700 rounded px-3 py-2 text-white outline-none" placeholder="Naam" value={newItem.name} onChange={e => setNewItem({...newItem, name: e.target.value})} required/>
                            <input className="bg-zinc-800 border-zinc-700 rounded px-3 py-2 text-white outline-none" placeholder="Categorie" value={newItem.category} onChange={e => setNewItem({...newItem, category: e.target.value})} required/>
                        </div>
                        <div className="grid grid-cols-3 gap-4">
                            <select className="bg-zinc-800 border-zinc-700 rounded px-3 py-2 text-white outline-none" value={newItem.type} onChange={e => setNewItem({...newItem, type: e.target.value})}>
                                <option value="CONSUMABLE">Verbruiksartikel</option>
                                <option value="UPSELL">Upsell / Verkoop</option>
                            </select>
                            <input type="number" className="bg-zinc-800 border-zinc-700 rounded px-3 py-2 text-white outline-none" placeholder="Aantal" value={newItem.quantity} onChange={e => setNewItem({...newItem, quantity: parseInt(e.target.value)})} required/>
                            <input type="number" className="bg-zinc-800 border-zinc-700 rounded px-3 py-2 text-white outline-none" placeholder="Min. Aantal" value={newItem.minQuantity} onChange={e => setNewItem({...newItem, minQuantity: parseInt(e.target.value)})} required/>
                        </div>
                        <div className="flex justify-end gap-2">
                            <Button type="button" variant="secondary" onClick={() => setShowAddForm(false)}>Annuleren</Button>
                            <Button type="submit">Toevoegen</Button>
                        </div>
                    </form>
                </Card>
        )}

        {activeTab === 'current' ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {state.inventory.map(item => (
                    <Card key={item.id} className="relative group hover:border-zinc-600 transition-colors">
                        <div className="flex justify-between items-start mb-2">
                            <div>
                                <h3 className="font-bold text-white">{item.name}</h3>
                                <p className="text-xs text-zinc-500">{item.category}</p>
                            </div>
                            {item.quantity <= item.minQuantity && <Badge color="red">Low Stock</Badge>}
                        </div>
                        
                        <div className="flex items-end gap-2 mb-4">
                            <span className={`text-2xl font-bold ${item.quantity <= item.minQuantity ? 'text-rose-500' : 'text-white'}`}>
                                {item.quantity}
                            </span>
                            <span className="text-xs text-zinc-500 mb-1">stuks</span>
                        </div>

                        <div className="flex gap-2 mt-auto">
                             <a href={item.reorderLink} target="_blank" rel="noreferrer" className="flex-1 flex items-center justify-center gap-2 p-2 bg-zinc-800 text-zinc-300 rounded hover:bg-zinc-700 text-sm transition-colors">
                                <ExternalLink size={14}/> Bestellen
                             </a>
                             <div className="flex items-center gap-1 bg-zinc-800 rounded">
                                 <button onClick={() => handleQuantityChange(item.id, -1, item.name)} className="px-3 py-2 hover:bg-zinc-700 text-zinc-400 hover:text-white rounded-l">-</button>
                                 <button onClick={() => handleQuantityChange(item.id, 1, item.name)} className="px-3 py-2 hover:bg-zinc-700 text-zinc-400 hover:text-white rounded-r">+</button>
                             </div>
                        </div>
                    </Card>
                ))}
            </div>
        ) : (
            <Card title="Logboek & Mutaties">
                <div className="space-y-0 divide-y divide-zinc-800 max-h-[600px] overflow-y-auto">
                    {state.inventoryTransactions.length === 0 && <p className="p-4 text-zinc-500 italic">Geen transacties.</p>}
                    {state.inventoryTransactions.sort((a,b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()).map(tx => (
                        <div key={tx.id} className="flex justify-between items-center p-4 hover:bg-zinc-800/30 transition-colors">
                             <div className="flex items-center gap-4">
                                 <div className={`p-2 rounded-full ${tx.type === 'USAGE' ? 'bg-rose-900/20 text-rose-500' : 'bg-emerald-900/20 text-emerald-500'}`}>
                                     {tx.type === 'USAGE' ? <Syringe size={16} /> : <Package size={16} />}
                                 </div>
                                 <div>
                                     <p className="text-white font-medium">{tx.itemName}</p>
                                     <p className="text-zinc-500 text-xs">{new Date(tx.timestamp).toLocaleString()}</p>
                                 </div>
                             </div>
                             <div className={`font-mono font-bold ${tx.change > 0 ? 'text-emerald-500' : 'text-rose-500'}`}>
                                 {tx.change > 0 ? '+' : ''}{tx.change}
                             </div>
                        </div>
                    ))}
                </div>
            </Card>
        )}
    </div>
  );
};

const FinanceView = () => {
    const { state, updateState } = useContext(AppContext);
    const [expenseForm, setExpenseForm] = useState<{name:string, amount:string, category:string, type:ExpenseType}>({ name: '', amount: '', category: '', type: 'VARIABLE' });
    const [isAddOpen, setIsAddOpen] = useState(false);
    const [editingExpense, setEditingExpense] = useState<Expense | null>(null);

    // --- Calculations ---
    const revenue = state.appointments
        .filter(a => a.status === AppointmentStatus.DONE)
        .reduce((sum, a) => sum + a.price, 0);
        
    const expensesTotal = state.expenses.reduce((sum, e) => sum + e.actualAmount, 0);
    const profit = revenue - expensesTotal;

    // --- Handlers ---
    const handleAddExpense = (e: React.FormEvent) => {
        e.preventDefault();
        if(!expenseForm.name || !expenseForm.amount) return;
        const expense: Expense = {
            id: `e${Date.now()}`,
            name: expenseForm.name,
            actualAmount: parseFloat(expenseForm.amount),
            estimatedAmount: expenseForm.type === 'FIXED' ? parseFloat(expenseForm.amount) : 0, 
            type: expenseForm.type,
            category: expenseForm.category || 'Overig',
            date: new Date().toISOString()
        };
        updateState({ expenses: [...state.expenses, expense] });
        setExpenseForm({ name: '', amount: '', category: '', type: 'VARIABLE' });
        setIsAddOpen(false);
    };

    const handleUpdateExpense = (updatedExpense: Expense) => {
        const updatedList = state.expenses.map(e => e.id === updatedExpense.id ? updatedExpense : e);
        updateState({ expenses: updatedList });
        setEditingExpense(null);
    };

    const handleDeleteExpense = (id: string, e: React.MouseEvent) => {
        e.stopPropagation(); 
        if(window.confirm('Verwijderen?')) {
            updateState({ expenses: state.expenses.filter(ex => ex.id !== id) });
        }
    };

    const getTransactionHistory = () => {
        const income = state.appointments
            .filter(a => a.status === AppointmentStatus.DONE)
            .map(a => ({ 
                id: a.id, 
                name: `Klant: ${state.clients.find(c=>c.id === a.clientId)?.name}`, 
                amount: a.price, 
                type: 'IN', 
                date: a.date,
                original: undefined
            }));
        
        const expenses = state.expenses.map(e => ({ 
            id: e.id, 
            name: e.name, 
            amount: e.actualAmount, 
            type: 'OUT', 
            date: e.date,
            original: e
        }));

        return [...income, ...expenses].sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    };

    return (
        <div className="space-y-6 animate-in fade-in duration-500">
             {editingExpense && (
                 <ExpenseModal 
                    expense={editingExpense} 
                    onClose={() => setEditingExpense(null)} 
                    onSave={handleUpdateExpense} 
                 />
             )}

             <h2 className="text-2xl font-bold text-white">Financieel Overzicht</h2>
             
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Card className="bg-emerald-900/10 border-emerald-900/30">
                    <p className="text-emerald-500/70 text-sm font-medium">Totale Omzet</p>
                    <p className="text-3xl font-bold text-emerald-400 mt-2">€{revenue.toFixed(2)}</p>
                </Card>
                <Card className="bg-rose-900/10 border-rose-900/30">
                    <p className="text-rose-500/70 text-sm font-medium">Totale Kosten</p>
                    <p className="text-3xl font-bold text-rose-400 mt-2">€{expensesTotal.toFixed(2)}</p>
                </Card>
                 <Card className="bg-blue-900/10 border-blue-900/30">
                    <p className="text-blue-500/70 text-sm font-medium">Netto Winst</p>
                    <p className={`text-3xl font-bold text-blue-400 mt-2`}>€{profit.toFixed(2)}</p>
                </Card>
            </div>
            
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2 space-y-6">
                    <Card title="Transactielijst (Inkomsten & Uitgaven)">
                         <div className="space-y-0 divide-y divide-zinc-800 max-h-[600px] overflow-y-auto">
                             {getTransactionHistory().map(tx => (
                                 <div 
                                    key={tx.id} 
                                    onClick={() => tx.type === 'OUT' && tx.original ? setEditingExpense(tx.original) : null}
                                    className={`flex justify-between items-center p-4 hover:bg-zinc-800/50 transition-colors ${tx.type === 'OUT' ? 'cursor-pointer' : ''}`}
                                 >
                                     <div className="flex items-center gap-4">
                                         <div className={`p-2 rounded-full ${tx.type === 'IN' ? 'bg-emerald-900/20 text-emerald-500' : 'bg-rose-900/20 text-rose-500'}`}>
                                             {tx.type === 'IN' ? <DollarSign size={16}/> : <TrendingDown size={16}/>}
                                         </div>
                                         <div>
                                             <p className="text-white font-medium">{tx.name}</p>
                                             <p className="text-xs text-zinc-500">{new Date(tx.date).toLocaleDateString()}</p>
                                         </div>
                                     </div>
                                     <div className="flex items-center gap-4">
                                         <span className={`font-mono font-bold ${tx.type === 'IN' ? 'text-emerald-400' : 'text-rose-400'}`}>
                                             {tx.type === 'IN' ? '+' : '-'}€{tx.amount.toFixed(2)}
                                         </span>
                                         {tx.type === 'OUT' && (
                                             <button onClick={(e) => handleDeleteExpense(tx.id, e)} className="text-zinc-600 hover:text-rose-500">
                                                 <Trash2 size={14}/>
                                             </button>
                                         )}
                                     </div>
                                 </div>
                             ))}
                         </div>
                    </Card>
                </div>

                <div className="space-y-6">
                     <div className="flex justify-end">
                         <Button onClick={() => setIsAddOpen(!isAddOpen)} className="flex gap-2 w-full">
                             <Plus size={16}/> Kosten Toevoegen
                         </Button>
                     </div>

                     {isAddOpen && (
                         <Card title="Nieuwe Kostenpost">
                            <form onSubmit={handleAddExpense} className="space-y-3">
                                <div className="space-y-1">
                                    <input className="w-full bg-zinc-800 border-zinc-700 rounded px-3 py-2 text-white outline-none" placeholder="Omschrijving" value={expenseForm.name} onChange={e => setExpenseForm({...expenseForm, name: e.target.value})} required/>
                                </div>
                                <div className="grid grid-cols-2 gap-3">
                                    <input type="number" className="bg-zinc-800 border-zinc-700 rounded px-3 py-2 text-white outline-none" placeholder="Bedrag (€)" value={expenseForm.amount} onChange={e => setExpenseForm({...expenseForm, amount: e.target.value})} required/>
                                    <input className="bg-zinc-800 border-zinc-700 rounded px-3 py-2 text-white outline-none" placeholder="Categorie" value={expenseForm.category} onChange={e => setExpenseForm({...expenseForm, category: e.target.value})}/>
                                </div>
                                <div className="space-y-1">
                                    <select className="w-full bg-zinc-800 border-zinc-700 rounded px-3 py-2 text-white outline-none" value={expenseForm.type} onChange={e => setExpenseForm({...expenseForm, type: e.target.value as ExpenseType})}>
                                        <option value="VARIABLE">Variabel / Eenmalig</option>
                                        <option value="FIXED">Vast / Maandelijks</option>
                                    </select>
                                </div>
                                <div className="flex justify-end gap-2 pt-2">
                                    <Button type="button" variant="secondary" onClick={() => setIsAddOpen(false)}>Annuleren</Button>
                                    <Button type="submit">Opslaan</Button>
                                </div>
                            </form>
                         </Card>
                     )}
                     
                     <Card title="Kosten Categorieën">
                         <div className="space-y-2">
                             {['Huisvesting', 'Materialen', 'Software', 'Overig'].map(cat => {
                                 const total = state.expenses.filter(e => e.category === cat).reduce((sum,e) => sum + e.actualAmount, 0);
                                 if (total === 0) return null;
                                 return (
                                     <div key={cat} className="flex justify-between text-sm p-2 bg-zinc-800/50 rounded">
                                         <span className="text-zinc-400">{cat}</span>
                                         <span className="text-white">€{total.toFixed(2)}</span>
                                     </div>
                                 )
                             })}
                         </div>
                     </Card>
                </div>
            </div>
        </div>
    );
};

const AccountingView = () => {
    const { state, updateState } = useContext(AppContext);
    const fileInputRef = useRef<HTMLInputElement>(null);

    const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            const newReceipt: ReceiptType = {
                id: `r${Date.now()}`,
                imageUrl: URL.createObjectURL(file), 
                date: new Date().toISOString(),
                amount: 0,
                description: 'Nieuwe bon (Concept)'
            };
            updateState({ receipts: [newReceipt, ...state.receipts] });
        }
    };

    return (
        <div className="space-y-6 animate-in fade-in duration-500">
             <div className="flex justify-between items-center bg-zinc-900 p-6 rounded-xl border border-zinc-800">
                 <div>
                    <h2 className="text-2xl font-bold text-white mb-2">Boekhouding</h2>
                    <p className="text-zinc-400 text-sm">Beheer bonnen en facturen voor de accountant.</p>
                 </div>
                 <div className="relative">
                    <input 
                        type="file" 
                        ref={fileInputRef}
                        className="hidden" 
                        accept="image/*"
                        onChange={handleFileUpload}
                    />
                    <Button onClick={() => fileInputRef.current?.click()} className="flex items-center gap-2 shadow-lg shadow-rose-900/20">
                        <Camera size={18}/> Scan Bon
                    </Button>
                 </div>
             </div>

             <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                 {state.receipts.map(receipt => (
                     <div key={receipt.id} className="group relative bg-zinc-900 border border-zinc-800 rounded-xl overflow-hidden hover:border-zinc-600 transition-all cursor-pointer">
                         <div className="aspect-[3/4] bg-zinc-800 relative overflow-hidden">
                             <img src={receipt.imageUrl} alt="Receipt" className="w-full h-full object-cover opacity-70 group-hover:opacity-100 group-hover:scale-105 transition-all duration-500" />
                             <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent flex flex-col justify-end p-4">
                                 <div className="transform translate-y-2 group-hover:translate-y-0 transition-transform">
                                    <p className="font-bold text-white text-lg mb-1">{receipt.description || 'Onbekend'}</p>
                                    <div className="flex justify-between items-end">
                                        <p className="text-zinc-400 text-sm">{new Date(receipt.date).toLocaleDateString()}</p>
                                        <p className="text-rose-400 font-mono font-bold">€{receipt.amount?.toFixed(2) || '-'}</p>
                                    </div>
                                 </div>
                             </div>
                         </div>
                     </div>
                 ))}
                 
                 {state.receipts.length === 0 && (
                     <div className="col-span-full py-12 text-center text-zinc-500 border-2 border-dashed border-zinc-800 rounded-xl">
                         <Receipt size={48} className="mx-auto mb-4 opacity-50"/>
                         <p>Nog geen bonnen geüpload.</p>
                     </div>
                 )}
             </div>
        </div>
    );
};

// --- Layout & Navigation ---

const SidebarItem = ({ icon: Icon, label, active, onClick }: { icon: any, label: string, active: boolean, onClick: () => void }) => (
  <button 
    onClick={onClick}
    className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
      active ? 'bg-rose-600 text-white shadow-lg shadow-rose-900/20' : 'text-zinc-400 hover:bg-zinc-800 hover:text-zinc-100'
    }`}
  >
    <Icon size={20} />
    <span className="font-medium">{label}</span>
  </button>
);

const MobileNav = () => {
  const { navigate, currentView } = useContext(AppContext);
  const navs = [
    { id: 'dashboard', icon: LayoutDashboard },
    { id: 'agenda', icon: Calendar },
    { id: 'clients', icon: Users },
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-zinc-950 border-t border-zinc-800 pb-safe z-50 md:hidden">
      <div className="flex justify-around p-2">
        {navs.map(n => (
          <button 
            key={n.id}
            onClick={() => navigate(n.id)}
            className={`p-3 rounded-full ${currentView === n.id ? 'text-rose-500 bg-rose-500/10' : 'text-zinc-500'}`}
          >
            <n.icon size={24} />
          </button>
        ))}
      </div>
    </div>
  );
};

const AppLayout = () => {
  const { state, currentView, navigate } = useContext(AppContext);

  const renderView = () => {
    switch (currentView) {
      case 'dashboard': return <DashboardView />;
      case 'agenda': return <AgendaView />;
      case 'clients': return <ClientsView />;
      case 'inventory': return <InventoryView />;
      case 'finance': return <FinanceView />;
      case 'accounting': return <AccountingView />;
      default: return <DashboardView />;
    }
  };

  return (
    <div className="min-h-screen bg-black text-zinc-100 font-sans selection:bg-rose-500/30">
      {/* Sidebar (Desktop) */}
      <aside className="hidden md:flex flex-col w-64 fixed inset-y-0 left-0 border-r border-zinc-800 bg-zinc-950 p-4">
        <div className="mb-8 px-4 py-2 flex items-center gap-2">
           <div className="w-8 h-8 bg-rose-600 rounded-lg flex items-center justify-center font-bold italic text-white shadow-lg shadow-rose-600/20">D</div>
           <h1 className="text-xl font-bold tracking-tight">Dolly Dagger</h1>
        </div>

        <nav className="flex-1 space-y-2">
          <SidebarItem icon={LayoutDashboard} label="Dashboard" active={currentView === 'dashboard'} onClick={() => navigate('dashboard')} />
          <SidebarItem icon={Calendar} label="Agenda" active={currentView === 'agenda'} onClick={() => navigate('agenda')} />
          <SidebarItem icon={Users} label="Klanten" active={currentView === 'clients'} onClick={() => navigate('clients')} />
          <SidebarItem icon={Package} label="Voorraad" active={currentView === 'inventory'} onClick={() => navigate('inventory')} />
          <SidebarItem icon={DollarSign} label="Financiën" active={currentView === 'finance'} onClick={() => navigate('finance')} />
          <SidebarItem icon={Receipt} label="Boekhouding" active={currentView === 'accounting'} onClick={() => navigate('accounting')} />
        </nav>

        <div className="mt-auto border-t border-zinc-800 pt-4 px-4">
           <div className="flex items-center gap-3">
             <img src={state.currentUser.avatar} alt="User" className="w-10 h-10 rounded-full border border-zinc-700" />
             <div>
               <p className="text-sm font-medium text-white">{state.currentUser.name}</p>
               <p className="text-xs text-zinc-500 capitalize">{state.currentUser.role.toLowerCase()}</p>
             </div>
           </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="md:ml-64 min-h-screen pb-20 md:pb-0">
        <div className="p-4 md:p-8 max-w-7xl mx-auto">
           {renderView()}
        </div>
      </main>

      <MobileNav />
    </div>
  );
};

// --- App Root Provider ---

const App = () => {
  const [state, setState] = useState<AppState>(initialState);
  const [currentView, setCurrentView] = useState('dashboard');

  const updateState = (updates: Partial<AppState>) => {
    setState(prev => ({ ...prev, ...updates }));
  };

  const navigate = (view: string) => {
    setCurrentView(view);
    window.scrollTo(0,0);
  };

  const contextValue = {
    state,
    updateState,
    navigate,
    currentView
  };

  return (
    <AppContext.Provider value={contextValue}>
      <AppLayout />
    </AppContext.Provider>
  );
};

export default App;