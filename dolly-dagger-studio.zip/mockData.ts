import { User, UserRole, Client, Appointment, AppointmentStatus, InventoryItem, Expense, InventoryTransaction, Receipt } from './types';

export const mockUsers: User[] = [
  { id: 'u1', name: 'Dolly Eigenaar', role: UserRole.OWNER, avatar: 'https://picsum.photos/100/100?random=1' },
  { id: 'u2', name: 'Jack Needle', role: UserRole.ARTIST, avatar: 'https://picsum.photos/100/100?random=2' },
  { id: 'u3', name: 'Sarah Ink', role: UserRole.ARTIST, avatar: 'https://picsum.photos/100/100?random=3' },
  { id: 'u4', name: 'Receptie Roxy', role: UserRole.RECEPTION, avatar: 'https://picsum.photos/100/100?random=4' },
];

export const mockClients: Client[] = [
  { id: 'c1', name: 'Alice Cooper', email: 'alice@example.com', phone: '06-12345678', instagram: 'alice_in_chains', medicalNotes: 'Latex allergie', tags: ['VIP', 'Grote Sessie'], waiverSigned: true, waiverDate: '2023-10-01' },
  { id: 'c2', name: 'Bob Marley', email: 'bob@example.com', phone: '06-87654321', instagram: 'rasta_bob', medicalNotes: 'Geen', tags: ['Laatkomer'], waiverSigned: false },
  { id: 'c3', name: 'Charlie Sheen', email: 'winning@example.com', phone: '06-11223344', instagram: 'tigerblood', medicalNotes: 'Gevoelige huid', tags: [], waiverSigned: true, waiverDate: '2023-11-15' },
];

export const mockAppointments: Appointment[] = [
  {
    id: 'a1',
    clientId: 'c1',
    artistId: 'u2',
    date: new Date().toISOString(), // Vandaag
    durationHours: 4.16, // 4 hours + 10 mins
    description: 'Traditionele schedel op onderarm',
    status: AppointmentStatus.CONFIRMED,
    price: 450,
    depositPaid: true,
    images: ['https://picsum.photos/200/300?random=10'],
    notes: []
  },
  {
    id: 'a2',
    clientId: 'c2',
    artistId: 'u3',
    date: new Date(Date.now() + 86400000).toISOString(), // Morgen
    durationHours: 2.16,
    description: 'Roos op schouder',
    status: AppointmentStatus.REQUESTED,
    price: 200,
    depositPaid: false,
    images: [],
    notes: []
  },
  {
    id: 'a3',
    clientId: 'c3',
    artistId: 'u2',
    date: new Date(Date.now() - 86400000).toISOString(), // Gisteren
    durationHours: 5.16,
    description: 'Volledige rug omlijning',
    status: AppointmentStatus.DONE,
    price: 600,
    depositPaid: true,
    images: ['https://picsum.photos/200/300?random=11'],
    notes: [
        { id: 'n1', content: 'Begonnen met lijnen, huid werd snel rood.', timestamp: new Date(Date.now() - 86400000).toISOString(), authorId: 'u2' }
    ]
  }
];

export const mockInventory: InventoryItem[] = [
  { id: 'i1', name: 'Zwarte Inkt (Dynamic)', category: 'Inkt', type: 'CONSUMABLE', quantity: 12, minQuantity: 5, reorderLink: 'https://supply.com' },
  { id: 'i2', name: 'Naalden 9RL', category: 'Naalden', type: 'CONSUMABLE', quantity: 3, minQuantity: 10, reorderLink: 'https://supply.com' },
  { id: 'i3', name: 'Handschoenen M', category: 'Hygiëne', type: 'CONSUMABLE', quantity: 50, minQuantity: 20, reorderLink: 'https://supply.com' },
  { id: 'i4', name: 'Groene Zeep', category: 'Hygiëne', type: 'CONSUMABLE', quantity: 1, minQuantity: 2, reorderLink: 'https://supply.com' },
  { id: 'i5', name: 'Aftercare Zalf Klein', category: 'Nazorg', type: 'UPSELL', quantity: 20, minQuantity: 5, reorderLink: 'https://supply.com' },
  { id: 'i6', name: 'T-Shirt Dolly Dagger', category: 'Merchandise', type: 'UPSELL', quantity: 10, minQuantity: 5, reorderLink: 'https://supply.com' },
];

export const mockExpenses: Expense[] = [
  { id: 'e1', name: 'Huur Studio', type: 'FIXED', estimatedAmount: 1500, actualAmount: 1500, date: new Date().toISOString(), category: 'Huisvesting' },
  { id: 'e2', name: 'Energie & Water', type: 'FIXED', estimatedAmount: 250, actualAmount: 280, date: new Date().toISOString(), category: 'Nutsvoorzieningen' },
  { id: 'e3', name: 'Software Licenties', type: 'FIXED', estimatedAmount: 50, actualAmount: 50, date: new Date().toISOString(), category: 'Software' },
  { id: 'e4', name: 'Extra Inkt Bestelling', type: 'VARIABLE', estimatedAmount: 0, actualAmount: 120, date: new Date().toISOString(), category: 'Materialen' },
  { id: 'e5', name: 'Lunch Team', type: 'VARIABLE', estimatedAmount: 0, actualAmount: 45, date: new Date().toISOString(), category: 'Overig' },
];

export const mockInventoryTransactions: InventoryTransaction[] = [
    { id: 'tx1', itemId: 'i2', itemName: 'Naalden 9RL', change: -1, type: 'USAGE', timestamp: new Date(Date.now() - 3600000).toISOString() },
    { id: 'tx2', itemId: 'i1', itemName: 'Zwarte Inkt (Dynamic)', change: 5, type: 'RESTOCK', timestamp: new Date(Date.now() - 86400000).toISOString() },
];

export const mockReceipts: Receipt[] = [
    { id: 'r1', imageUrl: 'https://picsum.photos/300/400?random=50', date: new Date().toISOString(), amount: 45.00, description: 'Lunch Team' }
];