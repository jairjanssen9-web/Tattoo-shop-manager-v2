import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateTattooConcept = async (description: string, style: string): Promise<string> => {
  try {
    const model = 'gemini-3-flash-preview';
    const prompt = `
      Ageer als een assistent voor een tattoo-artiest van wereldklasse.
      De klant wil een tattoo met deze beschrijving: "${description}".
      De gewenste stijl is: "${style}".
      
      Geef een creatieve, beknopte conceptbeschrijving voor de artiest in het Nederlands. 
      Neem suggesties op voor compositie, plaatsing en eventuele kleurenpaletten.
      Houd het professioneel en inspirerend.
    `;

    const response = await ai.models.generateContent({
      model: model,
      contents: prompt,
    });

    return response.text || "Geen concept gegenereerd.";
  } catch (error) {
    console.error("Gemini API Fout:", error);
    return "Kan op dit moment geen concept genereren. Probeer het later opnieuw.";
  }
};

export const summarizeNotes = async (rawNotes: string): Promise<string> => {
  try {
    const model = 'gemini-3-flash-preview';
    const prompt = `
      Vat de volgende ruwe notities, gemaakt tijdens een tattoosessie, samen in een schone lijst met opsommingstekens voor het dossier van de klant.
      Antwoord in het Nederlands.
      Benadruk specifieke nazorginstructies of vervolgafspraken indien genoemd.
      
      Ruwe Notities:
      "${rawNotes}"
    `;

    const response = await ai.models.generateContent({
      model: model,
      contents: prompt,
    });

    return response.text || "Geen samenvatting gegenereerd.";
  } catch (error) {
    console.error("Gemini API Fout:", error);
    return "Kan notities niet samenvatten.";
  }
};